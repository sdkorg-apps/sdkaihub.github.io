// Orgora Clipper popup. Shared source for Safari and Chrome.
//
// Asks the content script on the active tab for the profile it is showing,
// lets the user review/edit the fields, then hands the clip to the native
// side, which drops it in the shared app group container for Orgora Charts:
//   - Safari: the bundled app extension handler receives it directly.
//   - Chrome: the native messaging host installed by
//     tools/orgora-clipper-chrome/install.sh receives it; if that host
//     isn't set up, the popup offers downloading the clip as a .json file
//     which Orgora Charts can import manually.
// Entirely local — no network calls anywhere.

"use strict";

const runtime = typeof browser !== "undefined" ? browser : chrome;

const form = document.getElementById("form");
const hint = document.getElementById("hint");
const statusEl = document.getElementById("status");
const debugBtn = document.getElementById("copy-debug");
const fields = ["name", "title", "company", "location"];
let sourceUrl = "";
let photoDataUrl = "";
let debugSummary = "";

function setStatus(text, cls) {
  statusEl.textContent = text;
  statusEl.className = cls || "";
}

// Surfaces the content script's diagnostics (URL shape, page state,
// selector/element counts — never page content) behind a one-tap copy
// button, so a failed clip turns into an actionable report.
function offerDebugInfo(diag) {
  debugSummary = (diag && diag.summary) || "";
  debugBtn.hidden = !debugSummary;
}

debugBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(debugSummary);
    debugBtn.textContent = "Copied ✓";
  } catch {
    // Clipboard blocked: show the text so it can be selected by hand.
    const pre = document.createElement("pre");
    pre.style.cssText = "white-space:pre-wrap;font-size:11px;user-select:text;";
    pre.textContent = debugSummary;
    debugBtn.after(pre);
  }
});

async function init() {
  const tabs = await runtime.tabs.query({ active: true, currentWindow: true });
  const tab = tabs && tabs[0];
  if (!tab || !/^https:\/\/[^/]*\.?linkedin\.com\/(?:mwlite\/)?in\//.test(tab.url || "")) {
    hint.hidden = false;
    setStatus("This isn't a LinkedIn profile page.", "err");
    return;
  }

  let profile;
  try {
    profile = await runtime.tabs.sendMessage(tab.id, { action: "extract" });
  } catch {
    // The content script isn't in the page: either the page predates the
    // extension being enabled / allowed for linkedin.com, or access to the
    // site hasn't been granted yet.
    setStatus(
      "Couldn't reach the page. Make sure Orgora Clipper is allowed for " +
      "linkedin.com, then reload the profile and try again.",
      "err"
    );
    return;
  }
  if (!profile || profile.notProfile) {
    setStatus("Couldn't read the page — reload the profile and try again.", "err");
    offerDebugInfo(profile && profile.diag);
    return;
  }
  // Being signed in to the LinkedIn *app* is not enough — its session
  // isn't shared with the browser. Safari exposes the `browser` global.
  const browserName = typeof browser !== "undefined" ? "Safari" : "Chrome";
  const notSignedIn =
    "You're not signed in to LinkedIn in " + browserName + ". Log in at " +
    "linkedin.com in " + browserName + " (separate from the LinkedIn app) " +
    "and try again.";
  if (profile.authWall) {
    setStatus("LinkedIn is showing a login wall. " + notSignedIn, "err");
    offerDebugInfo(profile.diag);
    return;
  }
  if (profile.loggedOutEmpty) {
    setStatus(notSignedIn, "err");
    offerDebugInfo(profile.diag);
    return;
  }

  sourceUrl = profile.sourceUrl || tab.url;
  photoDataUrl = profile.photoDataUrl || "";
  if (photoDataUrl) {
    const preview = document.getElementById("photo");
    preview.src = photoDataUrl;
    preview.hidden = false;
  }
  for (const f of fields) {
    document.getElementById(f).value = profile[f] || "";
  }
  form.hidden = false;
  if (!profile.name) {
    setStatus(
      "Couldn't detect a name — fill it in before clipping, and copy the " +
      "debug info below if you're reporting this.", "err");
    offerDebugInfo(profile.diag);
  } else if (!profile.title && !profile.company) {
    // Partial extraction: clipping still works, but surface diagnostics.
    offerDebugInfo(profile.diag);
  }
}

function gatherClip() {
  const clip = { sourceUrl };
  if (photoDataUrl) clip.photoDataUrl = photoDataUrl;
  for (const f of fields) {
    clip[f] = document.getElementById(f).value.trim();
  }
  return clip;
}

document.getElementById("clip").addEventListener("click", async () => {
  const clip = gatherClip();
  if (!clip.name) {
    setStatus("A name is required.", "err");
    return;
  }
  const button = document.getElementById("clip");
  button.disabled = true;
  setStatus("Saving…");
  try {
    const response = await runtime.runtime.sendNativeMessage(
      "com.orgora.charts.clipper",
      { action: "clip", clip }
    );
    if (response && response.ok) {
      setStatus("Clipped. Open Orgora Charts to import.", "ok");
    } else {
      setStatus((response && response.error) || "Saving failed.", "err");
      button.disabled = false;
    }
  } catch (e) {
    // Chrome without the optional native host: save a clip file automatically
    // so the user is not stuck. Safari's bundled handler should not land here.
    downloadClip(clip);
    button.disabled = false;
  }
});

function downloadClip(clip) {
  if (!clip.name) {
    setStatus("A name is required.", "err");
    return;
  }
  const payload = Object.assign({}, clip, {
    clippedAt: new Date().toISOString(),
  });
  const blob = new Blob([JSON.stringify(payload, null, 2)],
    { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "orgora-clip-" + payload.clippedAt.replace(/[:.]/g, "-") + ".json";
  a.click();
  URL.revokeObjectURL(a.href);
  setStatus(
    "Downloaded. In Orgora Charts: clip inbox → Import clip files…", "ok");
}

document.getElementById("download").addEventListener("click", () => {
  downloadClip(gatherClip());
});

init();
