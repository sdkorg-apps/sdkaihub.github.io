Orgora Clipper for Google Chrome
================================

This folder is the finished extension. You do not write any code.

1. In Chrome, open chrome://extensions
2. Turn on Developer mode (top right)
3. Click "Load unpacked" and choose THIS folder (the one that contains
   manifest.json)
4. Pin Orgora Clipper from the puzzle-piece menu
5. Open a LinkedIn profile and click Clip to Orgora

Chrome saves a clip file. In Orgora Charts: clip inbox (clipboard icon
on the home screen) → Import clip files…

Safari users: Clipper is already inside Orgora Charts. Enable it in
Safari Settings → Extensions.

More detail: https://sdkaihub.com/orgora-charts/clipper.html
