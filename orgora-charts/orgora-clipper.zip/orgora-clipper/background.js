// Orgora Clipper background script. Shared source for Safari and Chrome
// (the manifest lists it under both background.scripts and
// background.service_worker; each browser picks the flavor it supports).
//
// Its only job is relaying clips to the native side: content scripts are
// not allowed to call runtime.sendNativeMessage (in Safari or Chrome), so
// the in-page "Clip to Orgora" button sends {action: "clipViaNative"} here
// and this script forwards it to the native handler — the bundled Safari
// app-extension handler, or the Chrome native-messaging host — exactly as
// the popup does directly. No network, no storage, no state.

"use strict";

const runtime = typeof browser !== "undefined" ? browser : chrome;

// Safari's bundled handler ignores the application name; Chrome uses it to
// find the registered native-messaging host manifest.
const NATIVE_HOST = "com.orgora.charts.clipper";

function sendNative(message) {
  // Promise-flavored in Safari/Firefox; callback-flavored in Chrome.
  return new Promise((resolve, reject) => {
    try {
      const maybePromise = runtime.runtime.sendNativeMessage(
        NATIVE_HOST, message, (response) => {
          const err = runtime.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(response);
        });
      if (maybePromise && typeof maybePromise.then === "function") {
        maybePromise.then(resolve, reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

runtime.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === "clipViaNative" && message.clip) {
    sendNative({ action: "clip", clip: message.clip })
      .then((response) => sendResponse(response || { ok: false, error: "No response from Orgora Charts." }))
      .catch((e) => sendResponse({ ok: false, error: (e && e.message) || "Native handler unreachable." }));
    return true; // keep the sendResponse channel open for the async reply
  }
});
