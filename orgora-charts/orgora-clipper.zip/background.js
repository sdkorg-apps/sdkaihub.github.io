// Orgora Clipper background script. Shared source for Safari and Chrome
// (the manifest lists it under both background.scripts and
// background.service_worker; each browser picks the flavor it supports).
//
// Relays clips to the native side (content scripts cannot call
// sendNativeMessage). "Open Orgora" prefers the installed app (Safari
// handler / Chrome native host). Chrome falls back to the public web app
// only when the native host is missing.

"use strict";

const runtime = typeof browser !== "undefined" ? browser : chrome;

// Safari's bundled handler ignores the application name; Chrome uses it to
// find the registered native-messaging host manifest.
const NATIVE_HOST = "com.orgora.charts.clipper";

// Public Open path (GitHub Pages /orgora/). Cache-bust query is optional;
// the live tip stamp is applied on the Pages deploy, not by the extension.
const ORGORA_OPEN_URL = "https://sdkaihub.com/orgora/";

function sendNative(message) {
  // Promise-flavored in Safari/Firefox; callback-flavored in Chrome.
  return new Promise((resolve, reject) => {
    try {
      const maybePromise = runtime.runtime.sendNativeMessage(
        NATIVE_HOST, message, (response) => {
          const err = runtime.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(response);
        });
      if (maybePromise && typeof maybePromise.then === "function") {
        maybePromise.then(resolve, reject);
      }
    } catch (e) {
      reject(e);
    }
  });
}

function isSafari() {
  return typeof browser !== "undefined";
}

function openNativeApp() {
  return sendNative({ action: "open" }).then((response) => {
    if (response && response.ok) return response;
    return {
      ok: false,
      error: (response && response.error) || "Native open failed.",
    };
  });
}

function isOrgoraWebUrl(url) {
  return typeof url === "string" &&
    url.indexOf("https://sdkaihub.com/orgora/") === 0;
}

function openUrlInTab(url) {
  // tabs.create works from the service worker / background page without the
  // "tabs" permission (that permission is only for reading tab details).
  return new Promise((resolve) => {
    try {
      const tabsApi = runtime.tabs;
      if (tabsApi && typeof tabsApi.create === "function") {
        const maybe = tabsApi.create({ url }, () => {
          const err = runtime.runtime.lastError;
          if (err) resolve({ ok: false, error: err.message });
          else resolve({ ok: true });
        });
        if (maybe && typeof maybe.then === "function") {
          maybe.then(() => resolve({ ok: true }), (e) => resolve({
            ok: false,
            error: (e && e.message) || "Could not open Orgora Charts.",
          }));
        }
        return;
      }
    } catch (e) {
      resolve({
        ok: false,
        error: (e && e.message) || "Could not open Orgora Charts.",
      });
      return;
    }
    resolve({ ok: false, error: "Could not open Orgora Charts." });
  });
}

function openOrgoraInBrowser() {
  return openUrlInTab(ORGORA_OPEN_URL);
}

runtime.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === "openOrgora") {
    openNativeApp()
      .then((response) => {
        if (response && response.ok) {
          sendResponse(response);
          return;
        }
        // Safari already fired https://sdkaihub.com/orgora/ under the user gesture.
        if (isSafari()) {
          sendResponse(response);
          return;
        }
        return openOrgoraInBrowser().then(sendResponse);
      })
      .catch((e) => {
        if (isSafari()) {
          sendResponse({
            ok: false,
            error: (e && e.message) || "Could not open Orgora Charts.",
          });
          return;
        }
        return openOrgoraInBrowser().then(sendResponse);
      });
    return true;
  }
  if (message && message.action === "openClipUrl" && isOrgoraWebUrl(message.url)) {
    openUrlInTab(message.url).then(sendResponse);
    return true;
  }
  if (message && message.action === "clipViaNative" && message.clip) {
    sendNative({ action: "clip", clip: message.clip })
      .then((response) => sendResponse(response || { ok: false, error: "No response from Orgora Charts." }))
      .catch((e) => sendResponse({ ok: false, error: (e && e.message) || "Native handler unreachable." }));
    return true;
  }
});
