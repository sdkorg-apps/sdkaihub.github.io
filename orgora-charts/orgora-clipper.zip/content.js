// Orgora Clipper content script.
//
// Injected on linkedin.com pages (LinkedIn is a single-page app: users
// usually reach a profile by soft navigation from the feed or search, with
// no full page load on the /in/… URL — so injection can't be limited to
// /in/* or the script would simply not exist on most profile visits).
// It only reads the page the user is already viewing. It performs no
// navigation, no background fetching, and no automation of any kind —
// extraction runs only when the user opens the popup or taps the in-page
// "Clip to Orgora" button, and only when the current page is a profile
// (/in/…).
//
// LinkedIn serves two very different documents:
//   - Logged OUT (public profile): server-rendered, with JSON-LD and og:
//     meta tags describing the profile.
//   - Logged IN: an Ember/React SPA with obfuscated, frequently-changing
//     class names. There is usually NO Person JSON-LD; instead the server
//     embeds Voyager API payloads as JSON inside hidden <code> elements
//     (ids like "bpr-guid-…"), and the visible top card is the only other
//     reliable source.
//
// Extraction is therefore layered, most-reliable first:
//   1. Voyager embedded JSON — <code>/<script> blocks parsed for an entity
//      whose publicIdentifier matches the /in/<slug> in the URL. Slug
//      matching makes this safe even after SPA soft navigation.
//   2. JSON-LD (<script type="application/ld+json">) — public pages only.
//      Trusted when the document was loaded on this URL, or when the
//      Person node's url matches the current slug.
//   3. Open Graph <meta> tags — only while the document is still on the
//      URL it was server-rendered for (they go stale on soft navigation).
//   4. Live DOM — semantic selectors (h1, aria labels) first, then legacy
//      class names, then generic structural heuristics (first h1 in main
//      and the text blocks that follow it) as the last resort.
//
// If the first pass finds an EMPTY SHELL (no h1 AND no <code> payloads —
// the page hasn't hydrated yet, common on slow guest loads), extraction
// waits for the content to appear (MutationObserver, bounded at ~5s) and
// re-runs before reporting failure. A guest page that never produces
// anything is reported as "not signed in to LinkedIn in this browser".
//
// Every extraction also returns a `diag` object (which layers matched,
// element counts, retry count, logged-in vs auth-wall state — never page
// content) so a failed clip produces an actionable bug report instead of
// "it's empty".

"use strict";

const runtime = typeof browser !== "undefined" ? browser : chrome;

// Path the document was actually server-rendered for. If the SPA has since
// navigated elsewhere, the static og: layer describes the wrong page and
// must be ignored.
const initialPath = location.pathname;

function profileSlug(path) {
  const m = /^\/(?:mwlite\/)?in\/([^/?#]+)/.exec(path || location.pathname);
  if (!m) return "";
  try {
    return decodeURIComponent(m[1]).toLowerCase();
  } catch {
    return m[1].toLowerCase();
  }
}

function isProfilePath() {
  return profileSlug() !== "";
}

// Stable profile URL for inbox/chart identity. Strips mwlite, overlay
// tails, query, and hash so two clips of the same person share one key.
function canonicalProfileUrl() {
  const path = location.pathname || "";
  const m = path.match(/(?:\/mwlite)?\/in\/([^/]+)/i);
  if (m) {
    return "https://www.linkedin.com/in/" + decodeURIComponent(m[1]);
  }
  return location.origin + path;
}

function staticLayersFresh() {
  return location.pathname === initialPath;
}

function textOf(el) {
  return el && el.textContent ? el.textContent.replace(/\s+/g, " ").trim() : "";
}

/* ---------- Page state (logged in / logged out / auth wall) ---------- */

// LinkedIn shows guests either a public profile (fine) or an "auth wall".
// The wall comes in several variants: a redirect to /authwall or a login
// path, a full-page "Join now / Sign in" form, and JS-rendered guest
// shells whose only content is a "Sign in to view …" prompt. Detecting
// them lets the UI say "log in and try again" instead of a generic
// failure. A sign-in prompt only counts as a wall when there is NO
// profile heading — public profiles legitimately carry "Sign in" links
// (and sometimes a dismissible contextual sign-in modal) next to real
// profile content.
function detectPageState() {
  if (/^\/(authwall|uas\/login|login|checkpoint|signup|start\/join)/.test(location.pathname)) {
    return "authwall";
  }
  // Markers of the logged-in chrome (nav bar / Me menu / global search).
  // LinkedIn has shipped several nav redesigns; keep a wide net so a
  // signed-in SPA is never classified as a guest empty shell.
  if (document.querySelector(
    "#global-nav, .global-nav__me, .search-global-typeahead, " +
    "header.global-nav, .global-nav, .authentication-outlet, " +
    "nav.global-nav, [data-test-global-nav], img.global-nav__me-photo, " +
    ".scaffold-layout__sidebar")) {
    return "loggedIn";
  }
  const wallPrompt = /\b(sign in|sign up|join now|log in|register)\b.*\bto (view|see|continue|access)\b/i;
  // A heading counts as profile content only if it isn't itself the wall's
  // "Sign in to view …" prompt.
  const h1 = document.querySelector("main h1") || document.querySelector("h1");
  const hasProfileHeading = !!h1 && !wallPrompt.test(textOf(h1));
  if (hasProfileHeading) return "loggedOut";
  const hasSignInForm = !!document.querySelector(
    'form[action*="authwall"], form[action*="/uas/login"], ' +
    'form[action*="/checkpoint"], input[name="session_key"], ' +
    'form.join-form, form[data-id="sign-in-form"]');
  if (hasSignInForm) return "authwall";
  // Join-now overlay pages / guest shells without a form element.
  if (document.querySelector(
    '[class*="authwall"], [id*="authwall"], ' +
    '[class*="contextual-sign-in"], [class*="join-form"], ' +
    '[data-tracking-control-name*="auth_wall"]')) {
    return "authwall";
  }
  // "Sign in to view …" text shells (headings/CTAs only — cheap check).
  for (const el of document.querySelectorAll("h1, h2, main p, main a, main button")) {
    if (wallPrompt.test(textOf(el))) return "authwall";
  }
  return "loggedOut";
}

/* ---------- Layer 1: Voyager embedded JSON (logged-in pages) ---------- */

// Depth-limited search for a LinkedIn "vector image" (rootUrl + artifacts
// with per-size path segments) anywhere inside a profile entity; the shape
// moves around between voyager schema versions.
function findVectorImageUrl(node, depth) {
  if (!node || typeof node !== "object" || depth > 6) return "";
  if (typeof node.rootUrl === "string" && Array.isArray(node.artifacts)) {
    let best = null;
    for (const a of node.artifacts) {
      if (!a || typeof a.fileIdentifyingUrlPathSegment !== "string") continue;
      const w = typeof a.width === "number" ? a.width : 0;
      // Smallest artifact at least 200px, else the largest available.
      if (!best ||
          (w >= 200 && (best.w < 200 || w < best.w)) ||
          (best.w < 200 && w > best.w)) {
        best = { w, seg: a.fileIdentifyingUrlPathSegment };
      }
    }
    return best ? node.rootUrl + best.seg : "";
  }
  for (const key of Object.keys(node)) {
    const found = findVectorImageUrl(node[key], depth + 1);
    if (found) return found;
  }
  return "";
}

function profileFromVoyagerEntity(entity) {
  const result = {};
  if (entity.firstName || entity.lastName) {
    result.name = [entity.firstName, entity.lastName]
      .filter(Boolean).map((s) => String(s).trim()).join(" ");
  }
  const headline = entity.headline || entity.occupation;
  if (headline) result.title = String(headline).trim();
  const loc = entity.geoLocationName || entity.locationName ||
    (entity.geoLocation && entity.geoLocation.defaultLocalizedName);
  if (loc) result.location = String(loc).trim();
  const photo = findVectorImageUrl(
    entity.profilePicture || entity.picture || null, 0);
  if (photo) result.photoUrl = photo;
  return result;
}

// Scans the hidden <code> blocks (and any JSON script blocks) LinkedIn
// embeds server-side voyager payloads in, looking for the entity whose
// publicIdentifier is the slug in the current URL. Matching on the slug —
// not on document freshness — means a stale payload for a different
// profile can never be mistaken for the one on screen.
function parseVoyagerJson(text) {
  const trimmed = (text || "").trim();
  if (!trimmed || trimmed.indexOf("publicIdentifier") === -1) return null;
  const candidates = [trimmed];
  if (trimmed.indexOf("&quot;") !== -1) {
    candidates.push(trimmed.replace(/&quot;/g, '"').replace(/&amp;/g, "&"));
  }
  for (const c of candidates) {
    const start = c.indexOf("{");
    if (start < 0) continue;
    try {
      return JSON.parse(c.slice(start));
    } catch {
      // Keep going — LinkedIn occasionally wraps extra junk around the object.
    }
  }
  return null;
}

function fromVoyager(diag) {
  const slug = profileSlug();
  // Prefer <code> / JSON script tags (classic voyager embed). Also accept
  // any non-JS <script> whose text mentions publicIdentifier — LinkedIn
  // has moved the payload between tag types.
  const blocks = document.querySelectorAll("code, script");
  diag.counts.codeBlocks = document.querySelectorAll(
    'code, script[type="application/json"]').length;
  let parsed = 0;
  let matches = 0;
  let best = {};
  for (const block of blocks) {
    if (block.tagName === "SCRIPT") {
      const type = (block.getAttribute("type") || "").toLowerCase();
      const id = block.id || "";
      if (type.indexOf("json") === -1 && id.indexOf("bpr") !== 0) {
        continue; // skip javascript bundles
      }
    }
    const data = parseVoyagerJson(block.textContent);
    if (!data) continue;
    parsed++;
    const entities = Array.isArray(data.included) ? data.included
      : (data.data && Array.isArray(data.data.included)) ? data.data.included
      : [data];
    for (const entity of entities) {
      if (!entity || typeof entity !== "object") continue;
      if (String(entity.publicIdentifier || "").toLowerCase() !== slug) continue;
      matches++;
      const extracted = profileFromVoyagerEntity(entity);
      // Merge: entities are fragmentary (miniProfile vs dash Profile), so
      // keep collecting fields across matching entities.
      for (const key of Object.keys(extracted)) {
        if (!best[key]) best[key] = extracted[key];
      }
    }
  }
  diag.counts.voyagerParsed = parsed;
  diag.counts.voyagerMatches = matches;
  return best;
}

/* ---------- Layer 2: JSON-LD (public pages) ---------- */

function jsonLdNodeMatchesSlug(node, slug) {
  if (!slug) return false;
  const urls = [node.url, node["@id"], node.mainEntityOfPage]
    .filter((u) => typeof u === "string");
  return urls.some((u) => u.toLowerCase().includes("/in/" + slug));
}

function fromJsonLd(diag) {
  const result = {};
  const scripts = document.querySelectorAll('script[type="application/ld+json"]');
  diag.counts.jsonLdScripts = scripts.length;
  const fresh = staticLayersFresh();
  const slug = profileSlug();
  for (const script of scripts) {
    let data;
    try {
      data = JSON.parse(script.textContent);
    } catch {
      continue;
    }
    let nodes = Array.isArray(data && data["@graph"])
      ? data["@graph"]
      : Array.isArray(data) ? data : [data];
    // Google's profile-page markup nests the Person inside a ProfilePage
    // node's mainEntity; unwrap those so the loop below sees the Person.
    nodes = nodes.map((node) =>
      node && node["@type"] === "ProfilePage" && node.mainEntity
        ? node.mainEntity
        : node);
    for (const node of nodes) {
      if (!node || node["@type"] !== "Person") continue;
      diag.counts.jsonLdPerson = (diag.counts.jsonLdPerson || 0) + 1;
      // After a soft navigation the JSON-LD describes the originally
      // loaded page — only trust it if its own URL names the current slug.
      if (!fresh && !jsonLdNodeMatchesSlug(node, slug)) continue;
      if (node.name) result.name = String(node.name).trim();
      const image = node.image;
      if (image) {
        const url = typeof image === "string"
          ? image
          : image.contentUrl || image.url || "";
        if (url) result.photoUrl = String(url).trim();
      }
      if (node.jobTitle) {
        result.title = Array.isArray(node.jobTitle)
          ? String(node.jobTitle[0]).trim()
          : String(node.jobTitle).trim();
      }
      const org = node.worksFor;
      if (org) {
        const first = Array.isArray(org) ? org[0] : org;
        if (first && first.name) result.company = String(first.name).trim();
      }
      const addr = node.address;
      if (addr && addr.addressLocality) {
        result.location = [addr.addressLocality, addr.addressCountry]
          .filter(Boolean).map(String).join(", ");
      }
      return result; // first matching Person node wins
    }
  }
  return result;
}

/* ---------- Layer 3: Open Graph meta tags ---------- */

function ogUrlMatchesProfile() {
  const el = document.querySelector('meta[property="og:url"]');
  const url = el ? (el.getAttribute("content") || "") : "";
  const slug = profileSlug();
  return !!slug && url.toLowerCase().includes("/in/" + slug);
}

// LinkedIn's SPA updates document.title on profile navigation even when
// the new view has not yet painted an h1 (the 2026 guest/soft-nav case).
// Ignore chrome titles (Feed, Search, …).
function fromDocumentTitle() {
  const raw = (document.title || "").trim();
  if (!raw) return {};
  const cleaned = raw
    .replace(/^\(\d+\)\s*/, "")
    .replace(/\s*[|·–-]\s*LinkedIn\s*$/i, "")
    .trim();
  if (!cleaned) return {};
  if (/^(feed|home|search|notifications|messaging|jobs|my network|linkedin)$/i
      .test(cleaned)) {
    return {};
  }
  const dash = cleaned.indexOf(" - ");
  if (dash > 0) {
    return {
      name: cleaned.slice(0, dash).trim(),
      title: cleaned.slice(dash + 3).trim(),
    };
  }
  return { name: cleaned };
}

function fromMetaTags() {
  const result = {};
  const og = (prop) => {
    const el = document.querySelector(`meta[property="og:${prop}"]`);
    return el ? (el.getAttribute("content") || "").trim() : "";
  };
  // og:title is typically "Name - Headline | LinkedIn" or "Name | LinkedIn".
  const title = og("title");
  if (title) {
    const withoutSuffix = title.replace(/\s*[|·]\s*LinkedIn\s*$/i, "");
    const dash = withoutSuffix.indexOf(" - ");
    if (dash > 0) {
      result.name = withoutSuffix.slice(0, dash).trim();
      result.title = withoutSuffix.slice(dash + 3).trim();
    } else {
      result.name = withoutSuffix.trim();
    }
  }
  // og:description sometimes leads with "Location · ..." context.
  const desc = og("description");
  if (desc) {
    const locMatch = desc.match(/^([^·:\n]{2,60})\s*·/);
    if (locMatch) result.location = locMatch[1].trim();
  }
  const image = og("image");
  if (image) result.photoUrl = image;
  return result;
}

/* ---------- Layer 4: live DOM ---------- */

// Generic structural fallback for the headline when every known selector
// misses (LinkedIn's SDUI pages use hashed class names that change on
// deploys): the headline is the first substantial text block after the h1
// in the top card. Badges ("· 3rd"), pronouns and counters are skipped.
function headlineNearH1(h1, name) {
  if (!h1) return "";
  let scope = h1.parentElement;
  for (let up = 0; up < 4 && scope; up++, scope = scope.parentElement) {
    for (const el of scope.querySelectorAll("div, span, p")) {
      const pos = h1.compareDocumentPosition(el);
      if (!(pos & Node.DOCUMENT_POSITION_FOLLOWING)) continue;
      if (el.querySelector("h1, button, a, input")) continue;
      const text = textOf(el);
      if (text.length < 3 || text.length > 180) continue;
      if (name && text === name) continue;
      if (/^\(?\s*(he|she|they)\s*\//i.test(text)) continue;      // pronouns
      if (/^·?\s*(1st|2nd|3rd)\b/.test(text)) continue;            // degree badge
      if (/\d+\s*(followers|connections)/i.test(text)) continue;   // counters
      if (/^(contact info|see contact info)$/i.test(text)) continue;
      return text;
    }
  }
  return "";
}

function fromDom(diag) {
  const result = {};
  const wallPrompt = /\b(sign in|sign up|join now|log in|register)\b.*\bto (view|see|continue|access)\b/i;

  // Name: the top-card h1 is the most reliable anchor across redesigns.
  // 2026 guest/SDUI pages sometimes omit <main> or use a title class
  // instead of h1 — still prefer a real heading over a sign-in prompt.
  const h1 = document.querySelector("main h1") || document.querySelector("h1");
  diag.counts.h1 = document.querySelectorAll("h1").length;
  let name = textOf(h1);
  if (!name || wallPrompt.test(name)) {
    const alt =
      document.querySelector(".top-card-layout__title") ||
      document.querySelector('[data-anonymize="person-name"]') ||
      document.querySelector('main [class*="top-card"] h2') ||
      document.querySelector(".pv-text-details__left-panel h1") ||
      document.querySelector(".pv-text-details__left-panel h2");
    const altText = textOf(alt);
    if (altText && !wallPrompt.test(altText)) name = altText;
  }
  result.name = name;

  // Headline: known selectors across the desktop/mobile logged-in SPA and
  // the public page, then the structural fallback near the h1.
  const headline =
    document.querySelector("main .text-body-medium.break-words") ||
    document.querySelector("main [data-generated-suggestion-target]") ||
    document.querySelector("main .top-card-layout__headline") ||
    document.querySelector('main [class*="headline"]') ||
    document.querySelector("main h1 + .text-body-medium") ||
    document.querySelector("main .text-body-medium");
  result.title = textOf(headline) || headlineNearH1(h1, result.name);

  // Location: small light text in the top card, before the contact link.
  const location =
    document.querySelector("main span.text-body-small.inline.t-black--light.break-words") ||
    document.querySelector("main .top-card-layout__first-subline span") ||
    document.querySelector("main span.text-body-small.t-black--light") ||
    document.querySelector('main [class*="top-card"] [class*="subline"] span');
  result.location = textOf(location);

  // Current company: the top-card "current company" affordance (aria label
  // is stabler than class names), then company-link / experience fallbacks.
  const companyBtn =
    document.querySelector('main [aria-label^="Current company"]') ||
    document.querySelector('main button[aria-label*="company"]') ||
    document.querySelector('main a[href*="/company/"] span[aria-hidden="true"]') ||
    document.querySelector('main [data-field="experience_company_logo"] span[aria-hidden="true"]');
  result.company = textOf(companyBtn);

  const photo = profileImgElement(result.name);
  if (photo && photo.src) result.photoUrl = photo.src;

  return result;
}

// The profile photo <img> already rendered in the top card (logged-in SPA
// and public page shapes). Prefer stable data-view-name / known class
// prefixes; hashed Ember classes and softer alt matching cover current LI.
function profileImgElement(name) {
  const known =
    document.querySelector(
      'main img[data-view-name="profile-top-card-member-photo"]') ||
    document.querySelector(
      'main [data-view-name="profile-top-card-member-photo"] img') ||
    document.querySelector("main img.pv-top-card-profile-picture__image--show") ||
    document.querySelector('main img[class*="pv-top-card-profile-picture"]') ||
    document.querySelector('main img[class*="top-card-layout__entity-image"]') ||
    document.querySelector('main img[class*="profile-photo"]') ||
    document.querySelector('main img[class*="profile-picture"]') ||
    // Hashed Ember/SDUI classes: circular headshot is usually the largest
    // square img near the top-card h1 (fallback when class names churn).
    largestSquareTopCardImg();
  if (known) return known;
  if (name) {
    const needle = name.trim().toLowerCase();
    if (needle) {
      for (const img of document.querySelectorAll("main img[alt]")) {
        const alt = (img.alt || "").trim().toLowerCase();
        if (!alt) continue;
        // Exact, prefix, or "Name …" / "… Name …" soft matches (LI varies).
        if (alt === needle || alt.startsWith(needle) || alt.includes(needle)) {
          return img;
        }
      }
    }
  }
  return null;
}

function largestSquareTopCardImg() {
  const h1 = document.querySelector("main h1") || document.querySelector("h1");
  const root = (h1 && h1.closest("section, div")) || document.querySelector("main");
  if (!root) return null;
  let best = null;
  let bestArea = 0;
  for (const img of root.querySelectorAll("img")) {
    const w = img.naturalWidth || img.width || parseInt(img.getAttribute("width") || "0", 10);
    const h = img.naturalHeight || img.height || parseInt(img.getAttribute("height") || "0", 10);
    if (!w || !h) continue;
    if (Math.abs(w - h) > Math.max(8, w * 0.15)) continue; // roughly square
    if (w < 48 || h < 48) continue;
    const area = w * h;
    if (area > bestArea) {
      best = img;
      bestArea = area;
    }
  }
  return best;
}

/* ---------- Photo capture ---------- */

// Downscale bound + JPEG quality: keeps a clip file at roughly 10-20 KB.
const PHOTO_MAX_DIM = 256;
const PHOTO_JPEG_QUALITY = 0.8;

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function scaledJpegDataUrl(img) {
  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  if (!w || !h) return "";
  const scale = Math.min(1, PHOTO_MAX_DIM / Math.max(w, h));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(w * scale));
  canvas.height = Math.max(1, Math.round(h * scale));
  canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
  // Throws on a tainted canvas — callers catch and give up silently.
  return canvas.toDataURL("image/jpeg", PHOTO_JPEG_QUALITY);
}

// Turns the profile photo into a small JPEG data URL, or "" when anything
// fails — the clip must always proceed without a photo rather than break.
// The only request made is for the image the page already displays, using
// the same session Safari/Chrome already used to render it.
async function capturePhotoDataUrl(photoUrl, name) {
  if (photoUrl && /^https:/.test(photoUrl)) {
    try {
      // LinkedIn's media CDN sends Access-Control-Allow-Origin: *, so a
      // plain CORS fetch works; the blob is same-origin for canvas purposes.
      const resp = await fetch(photoUrl, { credentials: "omit" });
      if (resp.ok) {
        const blob = await resp.blob();
        if (/^image\//.test(blob.type)) {
          const objectUrl = URL.createObjectURL(blob);
          try {
            return scaledJpegDataUrl(await loadImage(objectUrl));
          } finally {
            URL.revokeObjectURL(objectUrl);
          }
        }
      }
    } catch {
      // Fall through to the rendered-element fallback.
    }
  }
  // Fallback: draw the already-rendered <img> directly. If the browser
  // considers the canvas tainted, toDataURL throws and we give up.
  try {
    const el = profileImgElement(name);
    if (el && el.complete && el.naturalWidth) return scaledJpegDataUrl(el);
  } catch {
    // Silent: clip proceeds without a photo.
  }
  return "";
}

/* ---------- Merge + diagnostics ---------- */

function extensionVersion() {
  try {
    return runtime.runtime.getManifest().version || "?";
  } catch {
    return "?";
  }
}

// Human-readable diagnostic summary. Contains ONLY the profile URL, page
// state, element counts and which extraction layer supplied each field —
// never any page content — so it is safe to paste into a bug report.
function debugSummary(diag) {
  const c = diag.counts;
  const s = diag.sources;
  return [
    "Orgora Clipper debug (ext " + diag.extVersion + ")",
    "url: " + diag.url,
    "state: " + diag.state + (diag.staticFresh ? " (initial load)" : " (after soft navigation)"),
    "counts: codeBlocks=" + (c.codeBlocks || 0) +
      " voyagerParsed=" + (c.voyagerParsed || 0) +
      " voyagerMatches=" + (c.voyagerMatches || 0) +
      " jsonLd=" + (c.jsonLdScripts || 0) +
      " jsonLdPerson=" + (c.jsonLdPerson || 0) +
      " h1=" + (c.h1 || 0) +
      " retries=" + (c.retries || 0),
    "sources: name=" + (s.name || "none") +
      " title=" + (s.title || "none") +
      " company=" + (s.company || "none") +
      " location=" + (s.location || "none") +
      " photo=" + (s.photoUrl || "none"),
  ].join("\n");
}

async function extractProfileOnce(retries) {
  const diag = {
    extVersion: extensionVersion(),
    url: location.origin + location.pathname,
    state: detectPageState(),
    staticFresh: staticLayersFresh(),
    counts: { retries: retries || 0 },
    sources: {},
  };
  if (!isProfilePath()) {
    diag.summary = debugSummary(diag);
    return { notProfile: true, diag };
  }
  if (diag.state === "authwall") {
    diag.summary = debugSummary(diag);
    return { authWall: true, diag };
  }

  const layers = [
    ["voyager", fromVoyager(diag)],
    ["jsonld", fromJsonLd(diag)],
  ];
  // og: is stale after SPA navigation UNLESS LinkedIn updated og:url to
  // this profile (it often does, even when the h1 has not painted yet).
  if (diag.staticFresh || ogUrlMatchesProfile()) {
    layers.push(["og", fromMetaTags()]);
  }
  layers.push(["dom", fromDom(diag)]);
  layers.push(["title", fromDocumentTitle()]);

  const merged = { name: "", title: "", company: "", location: "", photoUrl: "" };
  for (const key of Object.keys(merged)) {
    for (const [layerName, layer] of layers) {
      if (layer[key]) {
        merged[key] = layer[key];
        diag.sources[key] = layerName;
        break;
      }
    }
  }
  // Last-resort company: many headlines are "Title at Company".
  if (!merged.company && merged.title) {
    const atMatch = merged.title.match(/\s(?:at|@)\s+([^|·,;]{2,60})\s*$/i);
    if (atMatch) {
      merged.company = atMatch[1].trim();
      diag.sources.company = "headline";
    }
  }

  merged.sourceUrl = canonicalProfileUrl();
  merged.photoDataUrl = await capturePhotoDataUrl(merged.photoUrl, merged.name);
  if (merged.photoDataUrl && !diag.sources.photoUrl) diag.sources.photoUrl = "dom";
  delete merged.photoUrl;
  diag.summary = debugSummary(diag);
  merged.diag = diag;
  return merged;
}

/* ---------- Empty-shell retry ---------- */

// LinkedIn's guest pages (and slow SPA loads) can hand the content script
// a document with literally nothing in it yet — no <code> payloads, no
// JSON-LD, no h1 — because the page hasn't hydrated/rendered when the user
// taps. Rather than reporting failure off an empty shell, wait (bounded)
// for the top card / embedded payloads to appear and re-extract.

// Overridable by the jsdom tests (which can't wait out the real bound on
// the never-hydrates path).
let hydrationTimeoutMs = 5000;
const MAX_EMPTY_SHELL_RETRIES = 2;

function isEmptyShell(diag, result) {
  if (result && result.name) return false;
  return !(diag.counts.h1 || 0) && !(diag.counts.codeBlocks || 0);
}

// Resolves when profile-ish content (h1, voyager <code>, JSON-LD) appears
// in the document, or after timeoutMs — whichever comes first.
function waitForHydration(timeoutMs) {
  return new Promise((resolve) => {
    const contentAppeared = () => {
      if (document.querySelector(
        'main h1, h1, h2, code, script[type="application/ld+json"], ' +
        'script[type="application/json"], .top-card-layout__title, ' +
        '[class*="authwall"], [class*="contextual-sign-in"]')) {
        return true;
      }
      return !!fromDocumentTitle().name;
    };
    if (timeoutMs <= 0 || contentAppeared()) {
      resolve(contentAppeared());
      return;
    }
    let observer = null;
    const timer = setTimeout(() => {
      if (observer) observer.disconnect();
      resolve(contentAppeared());
    }, timeoutMs);
    observer = new MutationObserver(() => {
      if (contentAppeared()) {
        clearTimeout(timer);
        observer.disconnect();
        resolve(true);
      }
    });
    observer.observe(document.documentElement || document,
      { childList: true, subtree: true });
  });
}

async function extractProfile() {
  const deadline = Date.now() + hydrationTimeoutMs;
  let retries = 0;
  let result = await extractProfileOnce(retries);
  while (!result.notProfile && !result.authWall &&
         isEmptyShell(result.diag, result) &&
         retries < MAX_EMPTY_SHELL_RETRIES && Date.now() < deadline) {
    const appeared = await waitForHydration(deadline - Date.now());
    retries++;
    // Re-run everything — including page-state classification: the shell
    // may have hydrated into an auth wall rather than a profile.
    result = await extractProfileOnce(retries);
    if (!appeared) break;
  }
  // A guest session whose page never produced anything (no payloads, no
  // heading) means the user isn't signed in to LinkedIn in THIS browser —
  // the most common iPad case: signed in via the LinkedIn app, which does
  // not share its session with Safari.
  if (!result.notProfile && !result.authWall && !result.name &&
      result.diag.state === "loggedOut" && isEmptyShell(result.diag, result)) {
    result.loggedOutEmpty = true;
  }
  return result;
}

// The message users get whenever the page demands a LinkedIn login the
// browser doesn't have (auth wall, or guest empty shell). Being signed in
// to the LinkedIn *app* is not enough — the app's session isn't shared
// with the browser. Safari exposes the `browser` global; Chrome doesn't.
const BROWSER_NAME = typeof browser !== "undefined" ? "Safari" : "Chrome";
const NOT_SIGNED_IN_MESSAGE =
  "You're not signed in to LinkedIn in " + BROWSER_NAME + ". Log in at " +
  "linkedin.com in " + BROWSER_NAME + " (separate from the LinkedIn app) " +
  "and try again.";

/* ---------- In-page "Clip to Orgora" button ---------- */

// A small floating button on profile pages (the founder-requested
// Lemlist-style flow): tap → extract → save via the native handler —
// without opening the extension popup. Purely passive UI: it triggers the
// exact same single-profile, user-initiated extraction as the popup.

const ORGORA_NS = "orgora-clipper";
let toastTimer = null;
// Last known headshot box, used so a LinkedIn SPA rerender that briefly
// drops the <img> does not destroy #orgora-clipper-photo.
let lastPhotoRect = null;
let photoMissStreak = 0;
const PHOTO_MISS_REMOVE = 8;
let clipInFlight = false;
let overlayGuardBound = false;
let lastClipAt = 0;
const CLIP_GESTURE_MS = 800;

function injectStylesOnce() {
  // iOS gold: page treatment = none. No full-page / photo-adjacent scrim,
  // dim overlay, or dark-grey backdrop. Only Clip buttons + toast.
  // If a calm dim is ever required later: only rgba(0,0,0,0.10) (8–12%).
  // Never LI #0A66C2 as backdrop.
  if (document.getElementById(ORGORA_NS + "-style")) return;
  const style = document.createElement("style");
  style.id = ORGORA_NS + "-style";
  style.textContent = `
#${ORGORA_NS}-host {
  position: fixed; inset: 0; pointer-events: none;
  z-index: 2147483646;
}
#${ORGORA_NS}-btn {
  /* Corner FAB: out-of-flow overlay. bottom well above LinkedIn's
     Messaging chip (~88px), so the pill never sits on it. */
  position: fixed; right: 14px; bottom: 152px; z-index: 2147483646;
  display: flex; align-items: center; gap: 7px;
  padding: 9px 14px; border: none; border-radius: 999px;
  margin: 0; width: auto;
  pointer-events: auto;
  background: #0f5f4c; color: #fff; cursor: pointer;
  font: 600 13px -apple-system, system-ui, sans-serif;
  box-shadow: 0 3px 12px rgba(0,0,0,.28);
}
#${ORGORA_NS}-btn:active { opacity: .8; }

#${ORGORA_NS}-btn img { width: 16px; height: 16px; border-radius: 4px; }
@media (min-width: 900px) { #${ORGORA_NS}-btn { right: 24px; } }
#${ORGORA_NS}-btn[data-anchor="photo"] {
  /* Legacy compact variant (single-button era); dual-button uses -photo. */
  padding: 6px 11px; gap: 5px;
  font: 600 12px -apple-system, system-ui, sans-serif;
  box-shadow: 0 2px 8px rgba(0,0,0,.22);
}
#${ORGORA_NS}-btn[data-anchor="photo"] img { width: 14px; height: 14px; }
#${ORGORA_NS}-photo {
  /* Photo-adjacent Orgora: badge at the BOTTOM-RIGHT of the circular headshot.
     Orgora green (iOS gold) — never LinkedIn #0A66C2. */
  position: fixed; z-index: 2147483646;
  display: flex; align-items: center; gap: 5px;
  padding: 6px 11px; border: none; border-radius: 999px;
  pointer-events: auto;
  background: #0f5f4c; color: #fff; cursor: pointer;
  font: 600 12px -apple-system, system-ui, sans-serif;
  box-shadow: 0 2px 8px rgba(0,0,0,.22);
}
#${ORGORA_NS}-photo img { width: 14px; height: 14px; border-radius: 4px; }
#${ORGORA_NS}-btn[data-busy="1"],
#${ORGORA_NS}-photo[data-busy="1"] { opacity: .6; cursor: default; }
#${ORGORA_NS}-toast {
  position: fixed; right: 14px; bottom: 204px; z-index: 2147483647;
  max-width: 280px; padding: 12px 14px; border-radius: 12px;
  background: #1c1e21; color: #fff;
  font: 13px/1.45 -apple-system, system-ui, sans-serif;
  box-shadow: 0 4px 16px rgba(0,0,0,.35);
}
@media (min-width: 900px) { #${ORGORA_NS}-toast { right: 24px; } }
#${ORGORA_NS}-toast.ok { background: #0f5f4c; }
#${ORGORA_NS}-toast button {
  display: block; margin-top: 8px; padding: 5px 10px;
  border: 1px solid rgba(255,255,255,.55); border-radius: 7px;
  background: transparent; color: #fff; cursor: pointer;
  font: 600 12px -apple-system, system-ui, sans-serif;
}
#${ORGORA_NS}-toast button.${ORGORA_NS}-open {
  display: inline; margin: 0; padding: 0; border: none;
  background: transparent; color: inherit; cursor: pointer;
  font: inherit; font-weight: 600; text-decoration: underline;
}`;
  (document.head || document.documentElement).appendChild(style);
}

function dismissToast() {
  const toast = document.getElementById(ORGORA_NS + "-toast");
  if (toast) toast.remove();
  if (toastTimer) {
    clearTimeout(toastTimer);
    toastTimer = null;
  }
}

function isSafari() {
  return typeof browser !== "undefined";
}

function fireAnchor(href) {
  const a = document.createElement("a");
  a.href = href;
  if (href.indexOf("https:") === 0) {
    a.target = "_blank";
    a.rel = "noopener noreferrer";
  }
  document.body.appendChild(a);
  a.click();
  a.remove();
}

// Open the same Orgora the clip was for: Safari (in-app Clipper) → the
// installed app. Chrome with the native host → the Mac app. Chrome
// without the host → public web.
function openOrgora() {
  if (isSafari()) {
    try { fireAnchor("https://sdkaihub.com/orgora/open"); } catch (_) {}
  }
  try {
    runtime.runtime.sendMessage({ action: "openOrgora" }, (response) => {
      if (response && response.ok) return;
      if (isSafari()) return;
      try { fireAnchor("https://sdkaihub.com/orgora/"); } catch (_) {}
    });
  } catch (_) {
    if (!isSafari()) {
      try { fireAnchor("https://sdkaihub.com/orgora/"); } catch (_) {}
    }
  }
}

function tappableOpenOrgora() {
  const openBtn = document.createElement("button");
  openBtn.type = "button";
  openBtn.className = ORGORA_NS + "-open";
  openBtn.textContent = "open Orgora Charts";
  openBtn.addEventListener("click", openOrgora);
  return openBtn;
}

function clippedSuccessMessage() {
  const frag = document.createDocumentFragment();
  frag.appendChild(document.createTextNode("Clipped ✓ — "));
  frag.appendChild(tappableOpenOrgora());
  frag.appendChild(document.createTextNode(" to import."));
  return frag;
}

function webOrgoraClipUrl(clip) {
  const payload = Object.assign({
    clippedAt: new Date().toISOString(),
  }, clip);
  let encoded = encodeURIComponent(JSON.stringify(payload));
  if (encoded.length > 400000 && payload.photoDataUrl) {
    delete payload.photoDataUrl;
    encoded = encodeURIComponent(JSON.stringify(payload));
  }
  return "https://sdkaihub.com/orgora/#orgora_clip=" + encoded;
}

function deliverClipToWeb(clip) {
  const url = webOrgoraClipUrl(clip);
  try {
    runtime.runtime.sendMessage({ action: "openClipUrl", url }, () => {
      const err = runtime.runtime.lastError;
      if (err) {
        try { fireAnchor(url); } catch (_) {}
      }
    });
  } catch (_) {
    try { fireAnchor(url); } catch (_) {}
  }
  showToast(clippedSuccessMessage(), true, []);
}

// Shows the floating toast. `text` is a string or a Node (e.g. the success
// message with a tappable "open Orgora Charts"). `actions` is a list of
// {label, onTap} buttons; the toast stays longer when it has actions or
// a tappable success control.
function showToast(text, ok, actions) {
  dismissToast();
  injectStylesOnce();
  const toast = document.createElement("div");
  toast.id = ORGORA_NS + "-toast";
  if (ok) toast.className = "ok";
  const message = document.createElement("div");
  if (text && typeof text === "object" && text.nodeType) {
    message.appendChild(text);
  } else {
    message.textContent = text;
  }
  toast.appendChild(message);
  for (const action of actions || []) {
    const btn = document.createElement("button");
    btn.textContent = action.label;
    btn.addEventListener("click", action.onTap);
    toast.appendChild(btn);
  }
  document.body.appendChild(toast);
  const linger = (actions && actions.length) ||
    (text && typeof text === "object" && text.nodeType);
  toastTimer = setTimeout(dismissToast, linger ? 14000 : 6000);
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Older engines / stricter contexts: textarea + execCommand fallback.
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

function copyDebugAction(diag) {
  return {
    label: "Copy debug info",
    onTap: async () => {
      const done = await copyText(diag && diag.summary ? diag.summary : "no diagnostics");
      showToast(done ? "Debug info copied — paste it into your report."
                     : "Couldn't copy — screenshot this instead:\n" +
                       ((diag && diag.summary) || ""), done, []);
    },
  };
}

// Explains which extraction layers came up empty, in founder-readable
// terms, and offers the copy-debug action.
function describeFailure(diag) {
  const c = diag.counts;
  const parts = [];
  if (!c.voyagerMatches) parts.push("embedded profile data");
  if (!c.jsonLdPerson) parts.push("structured data");
  if (!c.h1) parts.push("the profile heading");
  return "Couldn't read this profile (no " + parts.join(", no ") +
    " found). LinkedIn may have changed its page layout.";
}

function eventFromOverlay(e) {
  const t = e && e.target;
  if (!t || typeof t.closest !== "function") return false;
  return !!t.closest("#" + ORGORA_NS + "-host");
}

function eatOverlayEvent(e) {
  if (typeof e.preventDefault === "function") e.preventDefault();
  if (typeof e.stopPropagation === "function") e.stopPropagation();
  if (typeof e.stopImmediatePropagation === "function") {
    e.stopImmediatePropagation();
  }
}

// Window capture runs before LinkedIn's document listeners. Eat pointer
// events that hit our overlay so the headshot / cover carousel does not
// open and tear the photo chip down. Clip on click (jsdom) and pointerdown
// (Safari/Chrome); clipInFlight dedupes.
function bindOverlayGuard() {
  if (overlayGuardBound) return;
  overlayGuardBound = true;
  const onEat = (e) => {
    if (!eventFromOverlay(e)) return;
    eatOverlayEvent(e);
  };
  const onClip = (e) => {
    if (!eventFromOverlay(e)) return;
    if (e.type === "pointerdown" && e.button != null && e.button !== 0) {
      return;
    }
    eatOverlayEvent(e);
    if (e.target && typeof e.target.closest === "function" &&
        e.target.closest("button")) {
      onClipButtonTap();
    }
  };
  window.addEventListener("pointerdown", onClip, true);
  window.addEventListener("mousedown", onEat, true);
  window.addEventListener("touchstart", onEat, true);
  window.addEventListener("click", onClip, true);
}

function overlayHost() {
  bindOverlayGuard();
  let host = document.getElementById(ORGORA_NS + "-host");
  if (!host) {
    host = document.createElement("div");
    host.id = ORGORA_NS + "-host";
    host.setAttribute("role", "presentation");
  }
  const root = document.documentElement || document.body;
  if (!root) return null;
  // Keep the host last so it paints above LinkedIn's top-card overlays.
  if (host.parentNode !== root || root.lastElementChild !== host) {
    root.appendChild(host);
  }
  return host;
}

function setClipButtonsBusy(busy) {
  clipInFlight = !!busy;
  for (const id of [ORGORA_NS + "-btn", ORGORA_NS + "-photo"]) {
    const btn = document.getElementById(id);
    if (!btn) continue;
    if (busy) btn.setAttribute("data-busy", "1");
    else btn.removeAttribute("data-busy");
    btn.setAttribute("aria-busy", busy ? "true" : "false");
  }
}

async function onClipButtonTap() {
  const now = Date.now();
  if (clipInFlight) return;
  if (now - lastClipAt < CLIP_GESTURE_MS) return;
  lastClipAt = now;
  setClipButtonsBusy(true);
  try {
    const profile = await extractProfile();
    if (profile.authWall) {
      showToast("LinkedIn is showing a login wall. " + NOT_SIGNED_IN_MESSAGE,
        false, [copyDebugAction(profile.diag)]);
      return;
    }
    if (profile.notProfile) {
      showToast("This isn't a LinkedIn profile page.", false, []);
      return;
    }
    if (profile.loggedOutEmpty) {
      showToast(NOT_SIGNED_IN_MESSAGE, false, [copyDebugAction(profile.diag)]);
      return;
    }
    if (!profile.name) {
      showToast(describeFailure(profile.diag), false,
        [copyDebugAction(profile.diag)]);
      return;
    }
    const clip = {
      name: profile.name,
      title: profile.title,
      company: profile.company,
      location: profile.location,
      sourceUrl: profile.sourceUrl,
    };
    if (profile.photoDataUrl) clip.photoDataUrl = profile.photoDataUrl;
    // Content scripts can't call sendNativeMessage — relay through the
    // background script (background.js), which can.
    let response;
    try {
      response = await runtime.runtime.sendMessage(
        { action: "clipViaNative", clip });
    } catch (e) {
      response = { ok: false, error: (e && e.message) || "no background" };
    }
    if (response && response.ok) {
      showToast(clippedSuccessMessage(), true, []);
    } else if (isSafari()) {
      showToast(
        (response && response.error) || "Could not save this clip.",
        false, []);
    } else {
      // Chrome without the native host: open public Orgora with the clip
      // in the URL hash so Home can import it. Do not download a JSON file.
      deliverClipToWeb(clip);
    }
  } finally {
    setClipButtonsBusy(false);
  }
}

// The top-card profile photo the button anchors next to (founder request:
// the button should sit by the person's photo, not float in a corner).
function anchorPhotoElement() {
  const h1 = document.querySelector("main h1") || document.querySelector("h1");
  return profileImgElement(textOf(h1));
}

// Dual-button UX: always keep the corner FAB (#orgora-clipper-btn), and
// when the top-card photo is found add a compact Orgora (#orgora-clipper-photo)
// at the BOTTOM-RIGHT of the circular headshot (badge-ish, slightly outside
// the disc). position:fixed + getBoundingClientRect so scroll/resize stay
// exact without document-coordinate math. Both overlays are out-of-flow.
function makeClipButton(id, label) {
  const btn = document.createElement("button");
  btn.id = id;
  btn.type = "button";
  try {
    const icon = document.createElement("img");
    icon.src = runtime.runtime.getURL("images/icon-48.png");
    icon.alt = "";
    btn.appendChild(icon);
  } catch (_) {
    // Icon unavailable (no web_accessible_resources?) — text-only button.
  }
  btn.appendChild(document.createTextNode(label));
  return btn;
}

function applyPhotoPlacement(photoBtn, rect) {
  // Badge-ish: hang off the disc's bottom-right. Small overlap keeps it
  // attached; most of the pill sits outside LinkedIn's photo hit target.
  const overlap = 4;
  photoBtn.style.position = "fixed";
  photoBtn.style.left = Math.round(rect.right - overlap) + "px";
  photoBtn.style.top = Math.round(rect.bottom - overlap) + "px";
  photoBtn.style.right = "auto";
  photoBtn.style.bottom = "auto";
}

// Re-place using the live photo, or the last known rect on a transient
// miss. Scroll/resize must never destroy the button.
function placePhotoButton(photoBtn) {
  if (!photoBtn) return;
  const photoEl = anchorPhotoElement();
  if (photoEl) {
    lastPhotoRect = photoEl.getBoundingClientRect();
    applyPhotoPlacement(photoBtn, lastPhotoRect);
    return;
  }
  if (lastPhotoRect) applyPhotoPlacement(photoBtn, lastPhotoRect);
}

function syncClipButton() {
  // Drop legacy page scrim if an older tip left one behind.
  const legacyScrim = document.getElementById(ORGORA_NS + "-scrim");
  if (legacyScrim) legacyScrim.remove();
  const cornerId = ORGORA_NS + "-btn";
  const photoId = ORGORA_NS + "-photo";
  if (!isProfilePath()) {
    const host = document.getElementById(ORGORA_NS + "-host");
    if (host) host.remove();
    lastPhotoRect = null;
    photoMissStreak = 0;
    dismissToast();
    return;
  }
  if (!document.body && !document.documentElement) return;
  injectStylesOnce();
  const host = overlayHost();
  if (!host) return;
  let corner = document.getElementById(cornerId);
  if (!corner) {
    corner = makeClipButton(cornerId, "Clip to Orgora");
    corner.dataset.anchor = "fixed";
    host.appendChild(corner);
  } else if (corner.parentNode !== host) {
    host.appendChild(corner);
  }
  const photoEl = anchorPhotoElement();
  let photoBtn = document.getElementById(photoId);
  if (photoEl) {
    photoMissStreak = 0;
    if (!photoBtn) {
      photoBtn = makeClipButton(photoId, "Orgora");
      host.appendChild(photoBtn);
    } else if (photoBtn.parentNode !== host) {
      host.appendChild(photoBtn);
    }
    placePhotoButton(photoBtn);
    return;
  }
  // Transient SPA miss: keep the last rect and re-place. Remove only after
  // many consecutive misses (LinkedIn often drops the <img> for a tick).
  // Never tear the chip down while a clip from that chip is in flight.
  if (!photoBtn) return;
  if (clipInFlight) {
    if (lastPhotoRect) applyPhotoPlacement(photoBtn, lastPhotoRect);
    return;
  }
  photoMissStreak++;
  if (photoMissStreak >= PHOTO_MISS_REMOVE) {
    photoBtn.remove();
    lastPhotoRect = null;
    photoMissStreak = 0;
    return;
  }
  if (lastPhotoRect) applyPhotoPlacement(photoBtn, lastPhotoRect);
}

function repositionClipButton() {
  const photoBtn = document.getElementById(ORGORA_NS + "-photo");
  if (photoBtn) placePhotoButton(photoBtn);
}

/* ---------- Message handling + startup ---------- */

runtime.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === "extract") {
    // Async: the photo capture awaits a fetch + decode. Returning true
    // keeps the sendResponse channel open (works in Safari and Chrome).
    extractProfile().then(sendResponse);
    return true;
  }
});

syncClipButton();
setInterval(syncClipButton, 1000);
// capture:true so scrolls inside nested containers also re-anchor.
window.addEventListener("scroll", repositionClipButton,
  { passive: true, capture: true });
window.addEventListener("resize", repositionClipButton, { passive: true });

// Test hook: lets the fixture-based node tests drive the extractor
// directly. Content scripts run in an isolated world, so the page itself
// can never see or call this.
if (typeof window !== "undefined") {
  window.__orgoraClipperTest = {
    extractProfile,
    detectPageState,
    syncClipButton,
    setHydrationTimeout(ms) { hydrationTimeoutMs = ms; },
  };
}
